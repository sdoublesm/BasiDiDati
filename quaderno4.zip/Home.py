import streamlit as st
import numpy as np
import pandas as pd
from utils.utils import *

if __name__ == "__main__":
    st.set_page_config(
        page_title="Homepage | Quaderno 4",
        layout="centered",
        initial_sidebar_state="collapsed",
        menu_items={
            'Get Help': 'https://dbdmg.polito.it/',
            'About': "# Corso di *Basi di Dati*, creato da @sdoublesm"
        }
    )
    st.logo("images/med.png", link=None, icon_image=None)
        
    st.title("📓 Laboratorio 7 / Quaderno 4, powered by :violet[Streamlit]")
    st.markdown("##### Studente: :green[Mirko Tenore] - Matricola: :green[311756]")
    st.divider()
    st.markdown("""
                Ciao, benvenuto/a!\n
                L'obiettivo del Laboratorio/Quaderno è quello di creare un'applicazione web in Python 
                (utilizzando Streamlit) che sia in grado di interagire con un database MySQL in modo 
                da eseguire interrogazioni in base alle interazioni dell'utente.\n
                """)
    with st.chat_message(name="ai", avatar="🛜"):
        st.write("Per connetterti al database, apri il menu a tendina a sinistra e fai click sull'apposito tasto.")
   
    if "connection" not in st.session_state.keys():
        st.session_state["connection"]=False
    
    if check_connection():
            st.header("📊 Bar Chart", divider="grey")
            st.markdown("Il bar chart sottostante riporta il numero di lezioni per ogni slot di tempo.")
            q = """
                SELECT OraInizio, COUNT(*) NLezioni
                FROM Programma
                GROUP BY OraInizio
                ORDER BY OraInizio
                """
            result=execute_query(st.session_state["connection"], q)
            df=pd.DataFrame(result)
            st.bar_chart(df, x="OraInizio", y="NLezioni", color="#b27eff")

            st.header("📈 Area Chart", divider="grey")
            st.markdown("L'area chart sottostante riporta il numero di lezioni programmate in base al giorno della settimana.")
            q = """
                SELECT Giorno, COUNT(*) NLezioni
                FROM Programma
                GROUP BY Giorno
                """
            result=execute_query(st.session_state["connection"], q)
            df=pd.DataFrame(result)

            df['Giorno'] = pd.Categorical(df['Giorno'], categories=['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì'], ordered=True)
            df = df.sort_values('Giorno')
            
            st.area_chart(df, x="Giorno", y="NLezioni", color="#b27eff")