from utils.utils import *

if __name__ == "__main__":
    st.set_page_config(
        page_title="Istruttori | Quaderno 4",
        layout="centered",
        initial_sidebar_state="collapsed"
    )
    st.logo("images/med.png", link=None, icon_image=None)

    st.title("👨🏽‍🏫 Istruttori")
    with st.chat_message(name="ai", avatar="🛜"):
        st.write("Per connetterti al database, apri il menu a tendina a sinistra e fai click sull'apposito tasto.")
        
    if "connection" not in st.session_state.keys():
            st.session_state["connection"]=False

    if check_connection():
        st.markdown("Qui di seguito le informazioni riguardo gli istruttori.")
        q = "SELECT * FROM Istruttore;"
        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)
        
        #st.dataframe(df, hide_index = True, use_container_width=True)

        with st.expander("Filtri", True):
            opt_c = st.text_input("Inserisci Cognome per cui vuoi mostrare i risultati:")
            
            #lowliv, upliv = st.select_slider("Seleziona un range di date di nascita", options=[0, 1, 2, 3, 4], value=[0, 4])

            d = st.date_input(
                "Seleziona un range di date di nascita o una singola data:",
                (date(1980, 12, 1), date(2000, 12, 31)),
                date(1960, 1, 1),
                date(2005, 12, 31),
                format="DD.MM.YYYY",
            )

        if len(d)==2:
            if opt_c=='':
                q = "SELECT * FROM Istruttore WHERE DataNascita<='{}' AND DataNascita>='{}';".format(d[1].strftime("%Y-%m-%d"), d[0].strftime("%Y-%m-%d"))
            else:
                q = "SELECT * FROM Istruttore WHERE Cognome = '{}' AND DataNascita<='{}' AND DataNascita>='{}';".format(opt_c, d[1].strftime("%Y-%m-%d"), d[0].strftime("%Y-%m-%d"))
        elif len(d)==1:
            if opt_c=='':
                q = "SELECT * FROM Istruttore WHERE DataNascita='{}';".format(d[0].strftime("%Y-%m-%d"))
            else:
                q = "SELECT * FROM Istruttore WHERE Cognome = '{}' AND DataNascita='{}';".format(opt_c, d[0].strftime("%Y-%m-%d"))

        result=execute_query(st.session_state["connection"], q)

        st.header("🔍 Risultati", divider="grey")
        df = pd.DataFrame(result, index=None)
        
        if df.empty:
            with st.chat_message(name="ai", avatar="⚠️"):
                st.write("Nessun risultato.")
        else:
            #st.dataframe(df, hide_index = True, use_container_width=True)

            for index, row in df.iterrows():
                col1,col2, col3=st.columns(3)
                # col1.subheader(f":green[Risultato {index+1}]")
                col1.subheader(f":green[{row['Nome']} {row['Cognome']} ]")
                col2.text(f"""
                        CodFisc: {row['CodFisc']}
                        Nome: {row['Nome']}
                        Cognome: {row['Cognome']}
                        DataNascita: {row['DataNascita']}
                        Email: {row['Email']}
                        Telefono: {row['Telefono']}
                """)
                #col2.divider()
                col1.image(f"images/pers.png", width=70)