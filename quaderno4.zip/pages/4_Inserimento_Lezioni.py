from utils.utils import *

if __name__ == "__main__":
    st.set_page_config(
        page_title="Lezioni | Quaderno 4",
        layout="centered",
        initial_sidebar_state="collapsed"
    )    
    st.logo("images/med.png", link=None, icon_image=None)

    st.title("📅 Inserimento Lezioni")
    with st.chat_message(name="ai", avatar="🛜"):
        st.write("Per connetterti al database, apri il menu a tendina a sinistra e fai click sull'apposito tasto.")
    
    if "connection" not in st.session_state.keys():
            st.session_state["connection"]=False

    if check_connection():
        st.write("Qui di seguito i campi da compilare per l'inserimento di una nuova lezione settimanale nel database.")
        form = st.form("ins_lezioni")
        
        # -- CodFisc
        q = "SELECT CodFisc FROM Istruttore"
        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)
        codfisc = form.selectbox("Seleziona il codice fiscale dell'istruttore tra quelli disponibili:", df["CodFisc"], placeholder="Scegli opzione")

        # --- CodC
        q = "SELECT CodC FROM Corsi"
        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)
        codc = form.selectbox("Seleziona il codice del corso tra quelli disponibili:", df["CodC"], placeholder="Scegli opzione")

        # --- Sala
        sala = form.text_input("Seleziona il codice della sala:")

        # -- Giorno
        giorno = form.select_slider("Seleziona un giorno della settimana: ", options=["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì"]) 

        # -- OraInizio 
        orainizio = form.time_input("Inserisci orario di inizio:", value=None)
        # -- Durata
        durata = form.select_slider("Seleziona la durata della lezione: ", options=[20, 25, 30, 40, 45, 50, 60]) 
        
        submitted = form.form_submit_button("Submit")

        if submitted == True:
            if orainizio==None or sala=='':
                with st.chat_message(name="ai", avatar="⚠️"):
                    st.write("Non hai completato tutti i campi obblogatori.")
           
            else:
                q = "SELECT COUNT(*) FROM Programma WHERE CodC = '{}' AND Giorno = '{}';".format(codc, giorno)
                result=execute_query(st.session_state["connection"], q)
                if result.first()[0] == 0:
                    q = "INSERT INTO Programma (CodFisc, Giorno, OraInizio, Durata, CodC, Sala) VALUES ('{}', '{}', '{}', {}, '{}', '{}')".format(codfisc, giorno, orainizio.strftime("%H:%M:%S"), durata, codc, sala)
                    
                    try:
                        result=execute_query(st.session_state["connection"], q)
                        st.session_state["connection"].commit()
                        st.success("Inserimento della lezione di {}, tenuta da {} {} alle {} completato con successo.".format(codc, codfisc, giorno, orainizio), icon='✅')
                    except Exception as ex:
                        st.error("Errore: {}".format(ex.args[0]), icon='❌')
                else:
                    st.error("Una lezione per il corso {} è stata già programmata per {}".format(codc, giorno), icon='❌')

        st.header("🗂️ Lezioni", divider="grey")
        q = "SELECT * FROM Programma"
        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)
        st.dataframe(df, hide_index = True, use_container_width=True)

            
                 


