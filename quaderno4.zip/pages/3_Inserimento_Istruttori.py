from utils.utils import *

if __name__ == "__main__":
    st.set_page_config(
        page_title="Istruttori | Quaderno 4",
        layout="centered",
        initial_sidebar_state="collapsed"
    )    
    st.logo("images/med.png", link=None, icon_image=None)

    st.title("📋 Inserimento Istruttori")
    with st.chat_message(name="ai", avatar="🛜"):
        st.write("Per connetterti al database, apri il menu a tendina a sinistra e fai click sull'apposito tasto.")
    
    if "connection" not in st.session_state.keys():
            st.session_state["connection"]=False

    if check_connection():
        st.write("Qui di seguito i campi da compilare per l'inserimento di un nuovo istruttore nel database.")
        form = st.form("ins_istruttori")
        codfisc = form.text_input("Codice Fiscale *")
        nome = form.text_input("Nome *")
        cognome = form.text_input("Cognome *")
        # datanascita = form.text_input("Data Nascita")
        datanascita = form.date_input("Data di nascita *", date(1990, 8, 12))
        email = form.text_input("Email *")
        tel = form.text_input("Telefono")
        form.markdown("Nota: I campi contrassegnati con * sono obbligatori.")
        submitted = form.form_submit_button("Submit")

        if submitted == True:
            if  codfisc=='' or nome=='' or cognome=='' or email=='':
                with st.chat_message(name="ai", avatar="⚠️"):
                    st.write("Non hai completato tutti i campi obblogatori.") 
            if tel!='': 
                q = "INSERT INTO Istruttore (CodFisc, Nome, Cognome, DataNascita, Email, Telefono) VALUES ('{}', '{}', '{}', '{}', '{}', {})".format(codfisc, nome, cognome, datanascita.strftime("%Y-%m-%d"), email, tel)
            else:
                q = "INSERT INTO Istruttore (CodFisc, Nome, Cognome, DataNascita, Email) VALUES ('{}', '{}', '{}', '{}', '{}')".format(codfisc, nome, cognome, datanascita.strftime("%Y-%m-%d"), email)

            try:
                result=execute_query(st.session_state["connection"], q)
                st.session_state["connection"].commit()
                st.success("Inserimento dell'istruttore {} completato con successo".format(codfisc), icon='✅')
            except Exception as ex:
                st.error("Errore: {}".format(ex.args[0]), icon='❌')

        st.header("🗂️ Istruttori", divider="grey")
        q = "SELECT * FROM Istruttore"
        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)
        st.dataframe(df, hide_index = True, use_container_width=True)

            
                 


