import streamlit as st
from utils.utils import *
import pandas as pd

if __name__ == "__main__":
    st.set_page_config(
            page_title="Corsi | Quaderno 4",
            layout="centered",
            initial_sidebar_state="collapsed"
        )
    st.logo("images/med.png", link=None, icon_image=None)
    st.title("🏋🏽 Corsi")
    
    with st.chat_message(name="ai", avatar="🛜"):
        st.write("Per connetterti al database, apri il menu a tendina a sinistra e fai click sull'apposito tasto.")

    col1, col2 = st.columns(2)
    if "connection" not in st.session_state.keys():
        st.session_state["connection"]=False

    if check_connection():

        # numero di corsi e di tipi distinti disponibili
        with col1:
            q = """
                SELECT COUNT(DISTINCT CodC) NCorsi
                FROM Corsi
                """
            result=execute_query(st.session_state["connection"], q)
            st.metric(label="Numero Corsi", value=result.first()[0])
        with col2:
            q = """
                SELECT COUNT(DISTINCT Tipo) NTipi
                FROM Corsi;
                """
            result=execute_query(st.session_state["connection"], q)
            st.metric(label="Numero Tipi", value=result.first()[0])
                
        q = "SELECT * FROM Corsi;"
        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)

        with st.expander("Filtri", False):
            opt_a = st.selectbox("Secondo quale attributo vuoi filtrare i risultati?", df.columns.tolist()[0:3])
            opt_c = st.text_input("Seleziona {} per cui vuoi mostrare i risultati:".format(opt_a))
            lowliv, upliv = st.select_slider("Seleziona un range di livelli", options=[0, 1, 2, 3, 4], value=[0, 4])
        
        if opt_c != '':
            q = "SELECT * FROM Corsi WHERE {} = '{}' AND Livello<={} AND Livello>={};".format(opt_a, opt_c, upliv, lowliv)
        else:
            q = "SELECT * FROM Corsi WHERE Livello<={} AND Livello>={};".format(upliv, lowliv)

        result=execute_query(st.session_state["connection"], q)
        df = pd.DataFrame(result, index=None)
        if df.empty:
            with st.chat_message(name="ai", avatar="⚠️"):
                st.write("Nessun risultato.")
        else:
            st.dataframe(df, hide_index = True, use_container_width=True)
                    
        # i programmi delle lezioni per i corsi selezionati e nome e cognome dell’istruttore corrispondente.
        with st.expander("Programma delle lezioni per i corsi selezionati", True):
            if opt_c != '':
                q = """
                    SELECT P.CodC, Giorno, OraInizio, Durata, Sala, I.Nome, Cognome
                    FROM Programma P, Istruttore I, Corsi C
                    WHERE P.CodFisc = I.CodFisc
                    AND P.CodC = C.CodC
                    AND C.{} = '{}'
                    AND Livello<={} AND Livello>={}
                    """.format(opt_a, opt_c, upliv, lowliv)
            else:
                q = """
                    SELECT P.CodC, Giorno, OraInizio, Durata, Sala, I.Nome, Cognome
                    FROM Programma P, Istruttore I, Corsi C
                    WHERE P.CodFisc = I.CodFisc
                    AND P.CodC = C.CodC
                    AND Livello<={} AND Livello>={}
                    """.format(upliv, lowliv)
                
            result = execute_query(st.session_state["connection"], q)
            df = pd.DataFrame(result, index=None)
            if df.empty:
                with st.chat_message(name="ai", avatar="⚠️"):
                    st.write("Nessun risultato.")
            else:
                st.dataframe(df, hide_index = True, use_container_width=True)